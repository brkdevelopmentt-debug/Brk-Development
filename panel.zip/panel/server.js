const express = require('express');
const crypto = require('crypto');
const mysql = require('mysql');

// Paneli başlatıyoruz
const app = express();
app.use(express.json());

// Veritabanı bağlantısı (Kendi bilgilerine göre düzenle)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',      // XAMPP veya hostundaki kullanıcı adın
    password: '',      // Şifren varsa buraya yaz
    database: 'panel'  // Kendi veritabanı adını buraya yaz
});

db.connect((err) => {
    if (err) {
        console.error('Veritabanına bağlanılamadı:', err);
        return;
    }
    console.log('Veritabanına başarıyla bağlanıldı!');
});

// Rastgele API Key Üretme
function generateAPIKey() {
    return crypto.randomBytes(16).toString('hex');
}

// Kullanıcı API Key Alma / Oluşturma Sistemi
app.post('/api/get-key', (req, res) => {
    const userId = req.body.userId; 

    if (!userId) {
        return res.status(400).json({ error: 'Kullanıcı ID gerekli!' });
    }

    // Veritabanında kontrol et
    db.query('SELECT api_key FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Veritabanı hatası' });
        }

        if (results.length > 0 && results[0].api_key) {
            // Adamın zaten sabit bir key'i var, onu geri ver
            res.json({ success: true, apiKey: results[0].api_key });
        } else {
            // Key yoksa yeni oluştur ve kaydet
            const newKey = generateAPIKey();
            
            db.query('UPDATE users SET api_key = ? WHERE id = ?', [newKey, userId], (updateErr) => {
                if (updateErr) {
                    console.error(updateErr);
                    return res.status(500).json({ error: 'Key kaydedilemedi' });
                }
                res.json({ success: true, apiKey: newKey });
            });
        }
    });
});

// Sunucuyu 3000 portunda başlat
app.listen(3000, () => {
    console.log('Panel API 3000 portunda çalışıyor...');
});